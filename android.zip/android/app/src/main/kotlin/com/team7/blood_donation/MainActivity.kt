package com.team7.blood_donation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
